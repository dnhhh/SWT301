public interface LoginHandler {
    boolean login(String username, String password);
}
