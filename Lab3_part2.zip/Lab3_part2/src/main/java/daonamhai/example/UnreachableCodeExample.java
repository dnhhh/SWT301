import java.util.logging.Logger;

public class UnreachableCodeExample {
    private static final Logger LOGGER = Logger.getLogger(UnreachableCodeExample.class.getName());

    private static final int NUMBER = 42; // ✅ Declared as a constant

    public static void main(String[] args) {
        LOGGER.info("Returned number: " + NUMBER);
    }
}
