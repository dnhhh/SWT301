import java.io.*;
import java.util.logging.Logger;

public class PathTraversalExample {

    private static final Logger LOGGER = Logger.getLogger(PathTraversalExample.class.getName());
    private static final String BASE_DIRECTORY = "/safe/data"; // Change this to your allowed directory

    public static void main(String[] args) {
        String userInput = "../secret.txt"; // Simulated user input

        try {
            File baseDir = new File(BASE_DIRECTORY).getCanonicalFile();
            File requestedFile = new File(baseDir, userInput).getCanonicalFile();

            // Validate that the file is within the base directory
            if (!requestedFile.getPath().startsWith(baseDir.getPath())) {
                LOGGER.warning("Access denied: attempted path traversal");
                return;
            }

            if (requestedFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(requestedFile))) {
                    LOGGER.info("Reading file: " + requestedFile.getPath());
                    // Read and process content if needed
                }
            } else {
                LOGGER.warning("File does not exist: " + requestedFile.getPath());
            }
        } catch (IOException e) {
            LOGGER.severe("An error occurred while accessing the file: " + e.getMessage());
        }
    }
}
