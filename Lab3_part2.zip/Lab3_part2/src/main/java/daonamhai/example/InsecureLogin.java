package daonamhai.example;

import java.util.logging.Logger;

public class InsecureLogin {

    private static final Logger logger = Logger.getLogger(InsecureLogin.class.getName());

    public static void login(String username, String password) {
        String actualPassword = System.getenv("ADMIN_PASSWORD"); // Đọc từ biến môi trường
        if (username.equals("admin") && password.equals(actualPassword)) {
            logger.info("Login successful");
        } else {
            logger.warning("Login failed");
        }
    }

    public void printUserInfo(String user) {
        if (user != null && !user.isEmpty()) {
            logger.info("User: " + user);
        } else {
            logger.warning("User is null or empty");
        }
    }

    // Xoá hàm doNothing nếu không sử dụng
}
