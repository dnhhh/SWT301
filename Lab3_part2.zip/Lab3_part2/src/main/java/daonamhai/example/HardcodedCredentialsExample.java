import java.util.logging.Logger;

public class HardcodedCredentialsExample {

    private static final Logger LOGGER = Logger.getLogger(HardcodedCredentialsExample.class.getName());

    public static void main(String[] args) {
        // Retrieve credentials securely from environment variables
        String username = System.getenv("APP_USER");
        String password = System.getenv("APP_PASS");

        if (authenticate(username, password)) {
            LOGGER.info("Access granted");
        } else {
            LOGGER.warning("Access denied");
        }
    }

    private static boolean authenticate(String user, String pass) {
        // Dummy valid credentials (should also be externalized in real apps)
        final String VALID_USER = System.getenv("APP_USER");
        final String VALID_PASS = System.getenv("APP_PASS");

        return user != null && pass != null && user.equals(VALID_USER) && pass.equals(VALID_PASS);
    }
}
