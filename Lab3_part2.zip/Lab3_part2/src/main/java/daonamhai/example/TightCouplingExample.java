import java.util.logging.Logger;

// Interface abstraction
interface MessagePrinter {
    void print(String message);
}

// Logger-based implementation
class ConsoleLoggerPrinter implements MessagePrinter {
    private static final Logger LOGGER = Logger.getLogger(ConsoleLoggerPrinter.class.getName());

    @Override
    public void print(String message) {
        LOGGER.info(message);
    }
}

// Now Report depends on abstraction
class Report {
    private final MessagePrinter printer;

    public Report(MessagePrinter printer) {
        this.printer = printer;
    }

    public void generate() {
        printer.print("Generating report...");
    }
}

// Main class to demonstrate
public class ReportGenerator {
    public static void main(String[] args) {
        MessagePrinter printer = new ConsoleLoggerPrinter();
        Report report = new Report(printer);
        report.generate();
    }
}
