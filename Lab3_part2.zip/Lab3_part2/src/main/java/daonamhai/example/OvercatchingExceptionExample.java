import java.util.logging.Logger;

public class OvercatchingExceptionExample {
    private static final Logger LOGGER = Logger.getLogger(OvercatchingExceptionExample.class.getName());

    public static void main(String[] args) {
        try {
            int[] arr = new int[5];
            int value = arr[10]; // Triggers exception
            LOGGER.info("Value at index 10: " + value);
        } catch (ArrayIndexOutOfBoundsException e) {
            LOGGER.warning("Array index is out of bounds: " + e.getMessage());
        }
    }
}
