import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ResourceLeakExample {

    private static final Logger LOGGER = Logger.getLogger(ResourceLeakExample.class.getName());

    public static void main(String[] args) {
        String filePath = "data.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String finalLine = line;
                LOGGER.log(Level.INFO, () -> finalLine); // ✅ defer log message evaluation
            }

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, () -> "Error reading file: " + filePath, e); // ✅ lambda used
        }
    }
}
