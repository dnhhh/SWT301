import java.util.logging.Logger;

public class CatchSpecificExceptionExample {
    private static final Logger LOGGER = Logger.getLogger(CatchSpecificExceptionExample.class.getName());

    public static void main(String[] args) {
        String s = "default";  // Ensured non-null

        LOGGER.info("String length: " + s.length());
    }
}
