import java.util.logging.Logger;

interface Drawable {
    void draw();
}

public class Circle implements Drawable {
    private static final Logger LOGGER = Logger.getLogger(Circle.class.getName());

    @Override
    public void draw() {
        LOGGER.info("Drawing something...");
    }
}
