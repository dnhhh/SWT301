import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SQLInjectionExample {

    private static final Logger LOGGER = Logger.getLogger(SQLInjectionExample.class.getName());

    public static void main(String[] args) {
        String userInput = "' OR '1'='1"; // Simulated malicious input

        Properties dbProps = new Properties();
        try (FileInputStream fis = new FileInputStream("config.properties")) {
            dbProps.load(fis);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Cannot load database configuration", e);
            return;
        }

        String query = "SELECT username FROM users WHERE username = ?";

        try (Connection connection = DriverManager.getConnection(
                dbProps.getProperty("db.url"),
                dbProps.getProperty("db.user"),
                dbProps.getProperty("db.password"));
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, userInput);

            LOGGER.info("Prepared query safely without SELECT * and without hardcoded password.");

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error", e);
        }
    }
}
