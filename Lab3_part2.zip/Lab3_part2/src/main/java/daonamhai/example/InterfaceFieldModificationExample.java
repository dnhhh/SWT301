public final class Constants {
    public static final int MAX_USERS = 100;

    private Constants() {
        // prevent instantiation
    }
}


import java.util.logging.Logger;

public class InterfaceFieldModificationExample {
    private static final Logger LOGGER = Logger.getLogger(InterfaceFieldModificationExample.class.getName());

    public static void main(String[] args) {
        LOGGER.info("Maximum allowed users: " + Constants.MAX_USERS);
    }
}
