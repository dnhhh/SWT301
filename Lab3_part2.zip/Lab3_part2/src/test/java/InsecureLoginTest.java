import org.junit.jupiter.api.Test;
import daonamhai.example.InsecureLogin;

import static org.junit.jupiter.api.Assertions.*;

public class InsecureLoginTest {

    @Test
    public void testLoginSuccess() {
        InsecureLogin.login("admin", "123456");
    }

    @Test
    public void testLoginFail() {
        InsecureLogin.login("user", "wrongpassword");
    }

    @Test
    void testPrintUserInfo() {
        InsecureLogin insecureLogin = new InsecureLogin();
        insecureLogin.printUserInfo("John Doe");
    }

    @Test
    void testPrintUserInfoWithNull() {
        InsecureLogin insecureLogin = new InsecureLogin();
        insecureLogin.printUserInfo(null);  // tạo điều kiện để Sonar phát hiện nguy cơ null
    }
}
