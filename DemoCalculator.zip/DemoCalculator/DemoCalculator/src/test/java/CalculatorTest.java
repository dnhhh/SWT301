package daonamhai.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    @ParameterizedTest(name = "Test {0}({1}, {2}) = {3}")
    @CsvFileSource(resources = "/daonamhai/example/data.csv", numLinesToSkip = 1)
    @DisplayName("Calculator operations from CSV file")
    void testOperationsFromCSV(String operation, double a, double b, double expected) {
        double result;
        switch (operation) {
            case "add":
                result = calculator.add(a, b);
                break;
            case "subtract":
                result = calculator.subtract(a, b);
                break;
            case "multiply":
                result = calculator.multiply(a, b);
                break;
            case "divide":
                result = calculator.divide(a, b);
                break;
            default:
                throw new IllegalArgumentException("Invalid operation: " + operation);
        }

        assertEquals(expected, result, 0.001);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/daonamhai/example/divide-by-zero.csv", numLinesToSkip = 1)
    @DisplayName("Division by zero throws exception")
    void testDivideByZero(double a, double b) {
        assertThrows(ArithmeticException.class, () -> calculator.divide(a, b));
    }
}
