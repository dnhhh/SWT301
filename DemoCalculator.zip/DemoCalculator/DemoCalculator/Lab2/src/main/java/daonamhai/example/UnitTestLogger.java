package daonamhai.example;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Locale;

public class UnitTestLogger {
    private static final String FILE_PATH = "UnitTest.csv";
    private static boolean headerWritten = false;

    public static void logResult(String username, String password, String email, boolean expected, boolean actual) {
        try (BufferedWriter writer = Files.newBufferedWriter(
                Paths.get(FILE_PATH),
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND
        )) {
            if (!headerWritten && Files.size(Paths.get(FILE_PATH)) == 0) {
                writer.write("username,password,email,expected,actual\n");
                headerWritten = true;
            }

            writer.write(String.format(Locale.ROOT, "%s,%s,%s,%b,%b\n",
                    username, password, email, expected, actual));
        } catch (IOException e) {
            System.err.println("❌ Lỗi ghi log: " + e.getMessage());
        }
    }
}
