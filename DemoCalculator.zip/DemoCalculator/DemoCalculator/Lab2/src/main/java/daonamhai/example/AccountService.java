package daonamhai.example;

import java.util.HashSet;
import java.util.Set;

public class AccountService {
    // Danh sách lưu các username đã đăng ký
    private Set<String> registeredUsernames = new HashSet<>();

    /**
     * Kiểm tra email hợp lệ theo định dạng: abc@xyz.com
     */
    public boolean isValidEmail(String email) {
        return email != null && email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    /**
     * Kiểm tra mật khẩu mạnh:
     * - Tối thiểu 8 ký tự
     * - Có ít nhất 1 chữ hoa
     * - Có ít nhất 1 số
     * - Có ít nhất 1 ký tự đặc biệt
     */
    public boolean isStrongPassword(String password) {
        return password != null &&
                password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*\\d.*") &&
                password.matches(".*[!@#$%^&*()].*");
    }

    /**
     * Kiểm tra username đã được đăng ký hay chưa
     */
    public boolean isUsernameTaken(String username) {
        return registeredUsernames.contains(username);
    }

    /**
     * Kiểm tra email thuộc công ty (ví dụ @company.com)
     */
    public boolean isCompanyEmail(String email) {
        return email != null && email.endsWith("@company.com");
    }

    /**
     * Đăng ký tài khoản.
     * - Username không rỗng, chưa tồn tại
     * - Password dài hơn 6
     * - Email hợp lệ
     */
    public boolean registerAccount(String username, String password, String email) {
        if (username == null || username.isEmpty()) return false;
        if (isUsernameTaken(username)) return false;
        if (password == null || password.length() <= 6) return false;
        if (!isValidEmail(email)) return false;

        registeredUsernames.add(username); // Lưu username khi đăng ký thành công
        return true;
    }
}
